//
//  ViewController.swift
//  FAQView
//
//  Created by Shu on 6/17/22.
//

import UIKit

struct cellData {
    var opened = Bool()
    var title = String()
    var sectionData = [String]()
}

class TableViewController: UITableViewController {
    
    var tableViewData = [cellData]()

    override func viewDidLoad() {
        super.viewDidLoad()
        tableViewData = [cellData(opened: false, title: "Order ကိုဘယ်လိုပယ်ဖျက်နိုင်လဲ", sectionData: ["- MyPet app မှာအေကာင့်ဖွင့်ပါ", "- MyPet app မှာမိမိဝယ်ယူလိုသော items များကိုရိုက်ရှာပါ", "- Order Confirm ပါက Check Out ကိုနှိပ်ပါ"]),
                         cellData(opened: false, title: "Order ကိုဘယ်လိုပယ်ဖျက်နိုင်လဲ", sectionData: ["- MyPet app မှာအေကာင့်ဖွင့်ပါ", "- MyPet app မှာမိမိဝယ်ယူလိုသော items များကိုရိုက်ရှာပါ", "- Order Confirm ပါက Check Out ကိုနှိပ်ပါ"]),
                         cellData(opened: false, title: "Order ကိုဘယ်လိုပယ်ဖျက်နိုင်လဲ", sectionData: ["- MyPet app မှာအေကာင့်ဖွင့်ပါ", "- MyPet app မှာမိမိဝယ်ယူလိုသော items များကိုရိုက်ရှာပါ", "- Order Confirm ပါက Check Out ကိုနှိပ်ပါ"]),
                         cellData(opened: false, title: "Order ကိုဘယ်လိုပယ်ဖျက်နိုင်လဲ", sectionData: ["- MyPet app မှာအေကာင့်ဖွင့်ပါ", "- MyPet app မှာမိမိဝယ်ယူလိုသော items များကိုရိုက်ရှာပါ", "- Order Confirm ပါက Check Out ကိုနှိပ်ပါ"])
        ]
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return tableViewData.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableViewData[section].opened == true {
            return tableViewData[section].sectionData.count
        } else {
            return 1
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell") else {return UITableViewCell()}
            cell.textLabel?.text = tableViewData[indexPath.section].title
            return cell
        } else {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell") else {return UITableViewCell()}
            cell.textLabel?.text = tableViewData[indexPath.section].sectionData[indexPath.row]
            return cell
        }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableViewData[indexPath.section].opened == true {
            tableViewData[indexPath.section].opened = false
            let sections = IndexSet.init(integer: indexPath.section)
            tableView.reloadSections(sections, with: .none)
        } else {
            tableViewData[indexPath.section].opened = true
            let sections = IndexSet.init(integer: indexPath.section)
            tableView.reloadSections(sections, with: .none)
        }
    }
    
}

